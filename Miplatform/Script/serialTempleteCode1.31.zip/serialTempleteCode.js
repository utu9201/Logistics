﻿﻿﻿﻿﻿﻿﻿﻿//New Script File
//수주번호 생성함수
function estimateCodeNo(day){
var estiCnt=0;
var allEstimateRows=gds_estimate.GetRowCount();

	for(var idx=0; idx<allEstimateRows; idx++){
			var estimateNo=gds_estimate.GetColumn(idx,"ESTIMATE_NO");
			estiCnt=codeMaker(estiCnt);
			var newEstiNo="("+global_deptCode+"/"+global_empCode+")"+"ESTI"+day+"-"+estiCnt;
			iif(estimateNo=newEstiNo,estiCnt++,estiCnt);
		}
		estiCnt=codeMaker(estiCnt);
		var newEstiNo="("+global_deptCode+"/"+global_empCode+")"+"ESTI"+day+"-"+estiCnt;
		return newEstiNo;
}
//견적번호 생성함수
function contractCodeNo(day){
var contCnt=0;
gds_contract.unfilter();
var allContractRows=gds_contract.GetRowCount();

	for(var idx=0; idx<allContractRows; idx++){
			var contractNo=gds_contract.GetColumn(idx,"CONTRACT_NO");
			contCnt=codeMaker(contCnt);
			var newContNo="("+global_deptCode+"/"+global_empCode+")"+"CONT"+day+"-"+contCnt;
			iif(contractNo=newContNo,contCnt++,contCnt);
		}
		contCnt=codeMaker(contCnt);
		var newContNo="("+global_deptCode+"/"+global_empCode+")"+"CONT"+day+"-"+contCnt;
		this.gds_contract.Filter("DELIVERY_RESULT_STATUS!='Y'");
		var nRow=this.gds_contract.rowposition;
		var scode=this.gds_contract.GetColumn(nRow,"CONTRACT_NO");
		this.gds_contractDetail.Filter(" CONTRACT_NO=='"+scode+"'");

		return newContNo;
}

////견적상세번호 (글로벌 견적번호 입력)
function estimateDetailNo(estimateNo){
var estiDcnt=0;
		var allEstimateDetailRows=gds_estimateDetail.GetRowCount();
		
		for(var idx=0; idx<allEstimateDetailRows; idx++){
			var estimateDetailNo=gds_estimateDetail.GetColumn(idx,"ESTIMATE_DETAIL_NO");
			estiDcnt=codeMaker(estiDcnt);
			var newEstimateDetailNo=estimateNo+estiDcnt;
			iif(estimateDetailNo=newEstimateDetailNo,estiDcnt++,estiDcnt);
		}
		estiDcnt=codeMaker(estiDcnt);
		var newEstimateDetailNo=estimateNo+estiDcnt;
		return newEstimateDetailNo;

}
//// mps번호
function mpsNo(inputday){
var mpsCnt=0;
trace(inputday);
var allMpsRows=gds_mps.GetRowCount();

	for(var idx=0; idx<allMpsRows; idx++){
			var mpsNo=gds_mps.GetColumn(idx,"MPS_NO");
			mpsCnt=codeMaker(mpsCnt);
			var newMpsNo="("+global_deptCode+"/"+global_empCode+")"+"MPS"+inputday+"-"+mpsCnt;
			iif(mpsNo=newMpsNo,mpsCnt++,mpsCnt);
		}
		mpsCnt=codeMaker(mpsCnt);
		var newMpsNo="("+global_deptCode+"/"+global_empCode+")"+"MPSN"+inputday+"-"+mpsCnt;
		return newMpsNo;
}
//// 통합형 코드 프로토타입
function mpsNo(day,dataset,colname,serialID){
var Cnt=0;

var alldataRows=dataset.GetRowCount();

	for(var idx=0; idx<alldataRows; idx++){
			var oldNo=dataset.GetColumn(idx,colname);
			Cnt=codeMaker(Cnt);
			var newNo="("+global_deptCode+"/"+global_empCode+")"+serialID+day+"-"+Cnt;
			iif(oldNo=newNo,Cnt++,Cnt);
		}
		Cnt=codeMaker(Cnt);
		var newNo="("+global_deptCode+"/"+global_empCode+")"+serialID+day+"-"+Cnt;
		return newNo;
}





//01 형식의 번호생성 함수
function codeMaker(num) {
	num = ToString(num);
	trace(num);
 return iif(num.length >=2,  num ,"0"+ToString(num));
}

//각종 3자리 코드생성- 그리드에 바인드 데이터셋과 코드 칼럼명이 매개변수로 필요
function templeteCodeNo(gds_dataset,colname){
gds_dataset.unfilter();
	var newCodeCnt=0;
	trace(gds_dataset);
	trace(colname);
	var allGridRows=gds_dataset.GetRowCount();
	
	for(var idx=0; idx<allGridRows; idx++){
			var codeNo=gds_dataset.GetColumn(idx,colname);
			trace(codeNo);
			var originCode=codeNo.substr(0,3);
			trace(originCode);
			newCodeCnt=codeMaker(newCodeCnt,3);
			
			var newcodeNo=originCode+"-"+newCodeCnt;
			
			iif(codeNo=newcodeNo,newCodeCnt++,newCodeCnt);
		}
		newCodeCnt=codeMaker(newCodeCnt,3);
		var codeNo=gds_dataset.GetColumn(1,colname);
		var originCode=codeNo.substr(0,3);
		var newcodeNo=originCode+"-"+newCodeCnt;
		
		return newcodeNo;

}
